import { Item } from "./item";

export class Step {
    constructor(
        public id: number=0,
        public stepName:string="",
        public items: Item[]=[],
    ){}
}
