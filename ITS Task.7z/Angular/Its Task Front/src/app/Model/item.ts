export class Item {
    constructor(
        public id: number=0,
        public itemName:string="",
        public description:string="",
        public stepID:number=0,
    ){}
}
