import { Step } from './step';

describe('Step', () => {
  it('should create an instance', () => {
    expect(new Step()).toBeTruthy();
  });
});
