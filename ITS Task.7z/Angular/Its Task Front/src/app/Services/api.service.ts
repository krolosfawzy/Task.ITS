import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Step } from '../Model/step';
import { Item } from '../Model/item';
@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(private http: HttpClient) { }

  GetAllStep(){
    return this.http.get(environment.api_url + "GetAllStep");
  }

  AddStep = (Step:Step) => {
    return this.http.post(environment.api_url + "AddStep",Step);
  }

  DeleteStep = (Step:Step) => {
    return this.http.post(environment.api_url + "DeleteStep",Step);
  }

  GetAllItemByStepID = (StepID:number) => {
    return this.http.get(environment.api_url + "GetAllItemByStepID/?stepID=" + StepID);
  }

  AddItem = (Item:Item) => {
    return this.http.post(environment.api_url + "AddItem",Item);
  }

  DeleteItem = (Item:Item) => {
    return this.http.post(environment.api_url + "DeleteItem",Item);
  }

  EditItem = (Item:Item) => {
    return this.http.post(environment.api_url + "EditItem",Item);
  }

}
