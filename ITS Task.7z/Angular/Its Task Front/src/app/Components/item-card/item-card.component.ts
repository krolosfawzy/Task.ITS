import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/Services/api.service';
import { CommonService } from 'src/app/Shared/common.service';
import { Item} from 'src/app/Model/item';
import { Step } from 'src/app/Model/step';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-item-card',
  templateUrl: './item-card.component.html',
  styleUrls: ['./item-card.component.css']
})
export class ItemCardComponent implements OnInit {

  formGroup: FormGroup = this.formBuilder.group({
    itemName: [this.Common.selectedItem.itemName, [Validators.required, this.Common.removeSpaces]],
    description: [this.Common.selectedItem.description, [Validators.required, this.Common.removeSpaces]],
    id: [this.Common.selectedItem.id],
    stepID: [this.Common.selectedItem.stepID]
  });
  Item: Item = new Item();
  constructor(private apiServices: ApiService,
     public Common: CommonService,
      private formBuilder: FormBuilder) { }


  ngOnInit(): void {
    this.Common.spinner.show();
    if (this.Common.selectedStep.id != 0)
      this.apiServices.GetAllItemByStepID(this.Common.selectedStep.id).subscribe(
        (res) => { this.Common.items = res as Item[] },
        (err) => { console.log(err) },
        () => {/*sucsses*/this.Common.spinner.hide(); }
      );

      if (this.Common.subsVar==undefined) {    
        this.Common.subsVar = this.Common.    
        invokeItemComponentFunction.subscribe(() => {    
          this.clearForm();    
        });    
      }  
  }

  deleteItem(Item: Item) {
    this.Common.spinner.show();
    this.apiServices.DeleteItem(Item).subscribe(
      (res) => { this.Common.items = this.Common.items.filter((item) => item.id != Item.id); },
      (err) => { console.log(err) },
      () => {this.clearForm(); this.Common.spinner.hide();}
    );
  }

  fillForm(Item: Item,event:any) {
    this.Common.selectedItem=Item;
    if(document.getElementsByClassName("selectedItem")[0])
    document.getElementsByClassName("selectedItem")[0].classList.remove("selectedItem");
    event.target.className +=" selectedItem";
    this.formGroup.patchValue({
      itemName: Item.itemName,
      description: Item.description,
      id: Item.id,
      stepID: Item.stepID
    });
  }

  clearForm(){
    this.Common.selectedItem=new Item();
    if(document.getElementsByClassName("selectedItem")[0])
    document.getElementsByClassName("selectedItem")[0].classList.remove("selectedItem");
    this.formGroup = this.formBuilder.group({
      itemName: [this.Common.selectedItem.itemName, [Validators.required, this.Common.removeSpaces]],
    description: [this.Common.selectedItem.description, [Validators.required, this.Common.removeSpaces]],
    id: [this.Common.selectedItem.id],
    stepID: [this.Common.selectedItem.stepID]
    });
  }

  submit() {
    this.Common.spinner.show();
    this.formGroup.value.stepID=this.Common.selectedStep.id;
    //add
    if (this.formGroup.value.id == 0) {
      this.apiServices.AddItem(this.formGroup.value).subscribe(
        (res) => { this.Common.items.push(res as Item); },
        (err) => { console.log(err) },
        () => {/*sucsses*/this.Common.spinner.hide(); }
      );
    }

    //edit
    else {
      this.apiServices.EditItem(this.formGroup.value).subscribe(
        (res) => {
          var editItem = res as Item;
          this.Common.items.forEach(I => {
            if (I.id == editItem.id) {
              I.itemName = editItem.itemName;
              I.description = editItem.description;
            }
          });
        },
        (err) => { console.log(err) },
        () => {/*sucsses*/ this.Common.spinner.hide();}
      );
    }
    this.clearForm();
  }

  nextStep(){
    if(this.Common.selectedStep.id==0 && this.Common.steps.length>0){
      this.Common.selectStep(this.Common.steps[0].id.toString());
    }

    else if(this.Common.steps.length>0){
      var currentIndex=this.Common.steps.findIndex(s=>s.id==this.Common.selectedStep.id);
      if(this.Common.steps[currentIndex+1]){
        this.Common.selectedStep=this.Common.steps[currentIndex+1];
        this.Common.selectStep(this.Common.selectedStep.id.toString());
      }
    }
  }

  previousStep(){
    if(this.Common.selectedStep.id==0 && this.Common.steps.length>0){
      this.Common.selectStep(this.Common.steps[0].id.toString());
    }

    else if(this.Common.steps.length>0){
      var currentIndex=this.Common.steps.findIndex(s=>s.id==this.Common.selectedStep.id);
      if(this.Common.steps[currentIndex-1]){
        this.Common.selectedStep=this.Common.steps[currentIndex-1];
        this.Common.selectStep(this.Common.selectedStep.id.toString());
      }
    }
  }

}
