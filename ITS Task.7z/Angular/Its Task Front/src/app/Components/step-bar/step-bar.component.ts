import { Component, OnInit } from '@angular/core';
import { Item } from 'src/app/Model/item';
import { Step } from 'src/app/Model/step';
import { ApiService } from 'src/app/Services/api.service';
import { CommonService } from 'src/app/Shared/common.service';

@Component({
  selector: 'app-step-bar',
  templateUrl: './step-bar.component.html',
  styleUrls: ['./step-bar.component.css']
})
export class StepBarComponent implements OnInit {

  constructor(private apiServices: ApiService, public Common: CommonService) { }

  ngOnInit(): void {
    this.Common.spinner.show();
    this.apiServices.GetAllStep().subscribe(
      (res) => { this.Common.steps = res as Step[] },
      (err) => { console.log(err) },
      () => {/*sucsses*/ this.Common.spinner.hide();}
    );
  }

  getItem(Step: Step,event:any) {
    this.Common.spinner.show();
    this.Common.selectedStep=Step;
    this.Common.selectedItem=new Item();
    this.Common.clearFormItemComponent();
    this.Common.selectStep(Step.id.toString());
    this.apiServices.GetAllItemByStepID(Step.id).subscribe(
      (res) => { this.Common.items = res as Item[] },
      (err) => { console.log(err) },
      () => {/*sucsses*/this.Common.spinner.hide(); }
    );
  }

  addStep(){
    this.Common.spinner.show();
    var step=new Step();
    var nStep=this.Common.steps.length;
    step.stepName="step"+nStep++;
    this.apiServices.AddStep(step).subscribe(
      (res) => { this.Common.steps.push(res as Step);},
      (err) => { console.log(err) },
      () => {/*sucsses*/ this.Common.spinner.hide();}
    )
  }

  deleteStep(dStep:Step){
    this.Common.spinner.show();
    this.Common.clearFormItemComponent();
    this.apiServices.DeleteStep(dStep).subscribe(
      (res) => { this.Common.steps=this.Common.steps.filter((step)=>step.id!=dStep.id);},
      (err) => { console.log(err) },
      () => {this.Common.items=[];this.Common.selectedStep=new Step();this.Common.spinner.hide(); }
    )
  }

}
