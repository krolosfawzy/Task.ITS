import { Injectable, EventEmitter } from '@angular/core';
import { AbstractControl, FormControl, ValidationErrors, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subscription } from 'rxjs/internal/Subscription';
import { Item } from '../Model/item';
import { Step } from '../Model/step';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  steps: Step[] = [];
  items: Item[] = [];
  selectedStep: Step = new Step();
  selectedItem: Item = new Item();
  invokeItemComponentFunction = new EventEmitter();
  subsVar: Subscription | undefined;

  constructor(public spinner: NgxSpinnerService) { }



  removeSpaces = (control: AbstractControl) => {
    if (control && control.value && !control.value.replace(/\s/g, '').length) {
      
      control.setValue(null);
    }
    return false;
  }

  
  selectStep(id: string) {
    document.getElementById(id)?.click();
    var element = document.getElementById(id) as Element;
    if (document.getElementsByClassName("selectedStep")[0])
      document.getElementsByClassName("selectedStep")[0].classList.remove("selectedStep");
    element.className += " selectedStep";
  }

  clearFormItemComponent() {
    this.invokeItemComponentFunction.emit();
  }

}


