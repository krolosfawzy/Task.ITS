﻿using ITSTask.DTO;
using ITSTask.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.IRepository
{
     public interface IItemRepository : IRepository<Item>
    {
        IEnumerable<ItemDTO> GetAllItemByStepID(int stepID);
        ItemDTO getLastRecord();
    }
}
