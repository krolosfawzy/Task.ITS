﻿using ITSTask.DTO;
using ITSTask.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.IRepository
{
    public interface IStepRepository : IRepository<Step>
    {
       void AddStep(StepDTO step);
        StepDTO getLastRecord();
        void deleteItemOfStep(StepDTO step);
    }
}
