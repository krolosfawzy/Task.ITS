﻿using System;
using ITSTask.IRepository;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using ITSTask.Model;
using ITSTask.DTO;

namespace ITSTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("CORS")]
    public class ValuesController : ControllerBase
    {
        #region Declarations
        private readonly IStepRepository _StepRepository;
        private readonly IItemRepository _ItemRepository;
        #endregion

        public ValuesController(IStepRepository Step, IItemRepository Item)
        {
            _StepRepository = Step;
            _ItemRepository = Item;
        }

        #region api Step
        [Route("~/api/GetAllStep")]
        [HttpGet]
        public IActionResult GetAllStep()
        {
            try
            {
                var result = _StepRepository.GetAll();
                return Ok(result);
            }
            catch (Exception ex)
            {

                
                throw;
            }
        }

        [Route("~/api/AddStep")]
        [HttpPost]
        public IActionResult AddStep(StepDTO step)
        {

            try
            {
                Step stepModel = new Step()
                {
                    ID = step.ID,
                    items = step.items,
                    StepName = step.StepName,
                };
                _StepRepository.Create(stepModel);
                var result = _StepRepository.getLastRecord();
                return Ok(result);
            }
            catch (Exception ex)
            {

                
                throw;
            }
        }

        [Route("~/api/DeleteStep")]
        [HttpPost]
        public IActionResult DeleteStep(StepDTO step)
        {
           
            try
            {
                _StepRepository.deleteItemOfStep(step);
                
                return Ok(step);
            }
            catch (Exception ex)
            {


                throw;
            }
        }
        #endregion

        #region api Item
        [Route("~/api/GetAllItemByStepID")]
        [HttpGet]
        public IActionResult GetAllItemByStepID(int stepID)
        {
            try
            {
                var result = _ItemRepository.GetAllItemByStepID(stepID);
                return Ok(result);
            }
            catch (Exception ex)
            {


                throw;
            }
        }

        [Route("~/api/AddItem")]
        [HttpPost]
        public IActionResult AddItem(ItemDTO item)
        {

            try
            {
                Item ItemModel = new Item()
                {
                     ID=item.ID,
                     ItemName=item.ItemName,
                     Description=item.Description,
                     StepID=item.StepID,
                };
                _ItemRepository.Create(ItemModel);

                return Ok(_ItemRepository.getLastRecord());
            }
            catch (Exception ex)
            {


                throw;
            }
        }

        [Route("~/api/DeleteItem")]
        [HttpPost]
        public IActionResult DeleteItem(ItemDTO item)
        {

            try
            {
                Item ItemModel = new Item()
                {
                    ID = item.ID,
                    ItemName = item.ItemName,
                    Description = item.Description,
                    StepID = item.StepID,
                };
                _ItemRepository.Delete(ItemModel);
                return Ok(item);
            }
            catch (Exception ex)
            {


                throw;
            }
        }

        [Route("~/api/EditItem")]
        [HttpPost]
        public IActionResult EditItem(ItemDTO item)
        {
           
            try
            {
                Item ItemModel = new Item()
                {
                    ID = item.ID,
                    ItemName = item.ItemName,
                    Description = item.Description,
                    StepID = item.StepID,
                };
                _ItemRepository.Update(ItemModel);
                return Ok(item);
            }
            catch (Exception ex)
            {
                return Ok(ex.ToString());

                throw;
            }
        }
        #endregion
    }
}
