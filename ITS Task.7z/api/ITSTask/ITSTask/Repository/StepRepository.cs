﻿using ITSTask.DTO;
using ITSTask.IRepository;
using ITSTask.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.Repository
{
    public class StepRepository : Repository<Step>, IStepRepository
    {
        public StepRepository(ApplicationDbContext context) : base(context)
        {

        }

        public void AddStep(StepDTO step)
        {
            Step stepModel = new Step()
            {
                ID = step.ID,
                items = step.items,
                StepName=step.StepName,
            };
            _context.Steps.Add(stepModel);

            _context.SaveChanges();
        }

        public StepDTO getLastRecord()
        {
            var query = (from s in _context.Steps
                         select new StepDTO
                         {
                             ID = s.ID,
                             StepName = s.StepName,
                             items = s.items,
                         }).LastOrDefault();
            return query;
        }

        public void deleteItemOfStep(StepDTO step) {
            var query= (from I in _context.Items
                        where I.StepID==step.ID
                        select I
                        ).ToList();
            _context.Items.RemoveRange(query);
            _context.SaveChanges();
            Step stepModel = new Step()
            {
                ID = step.ID,
                items = step.items,
                StepName = step.StepName,
            };
            _context.Remove(stepModel);
            _context.SaveChanges();
        }

    }
}
