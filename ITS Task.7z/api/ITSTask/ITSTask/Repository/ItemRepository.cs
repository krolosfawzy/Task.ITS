﻿using ITSTask.DTO;
using ITSTask.IRepository;
using ITSTask.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.Repository
{
    public class ItemRepository : Repository<Item>, IItemRepository
    {
        public ItemRepository(ApplicationDbContext context) : base(context)
        {

        }

        public IEnumerable<ItemDTO> GetAllItemByStepID(int stepID)
        {
            var query = (from I in _context.Items
                        where I.StepID == stepID /*&& q.Labid == Labid */
                        select new ItemDTO
                        {
                           ID=I.ID,
                           ItemName=I.ItemName,
                           Description=I.Description,
                           StepID=I.StepID,
                        }).ToList();
            return query;
        }

        public ItemDTO getLastRecord()
        {
            var query = (from I in _context.Items
                         select new ItemDTO
                         {
                             ID = I.ID,
                             ItemName = I.ItemName,
                             Description = I.Description,
                             StepID=I.StepID
                         }).LastOrDefault();
            return query;
        }


    }
}
