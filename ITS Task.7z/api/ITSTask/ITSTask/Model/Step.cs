﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.Model
{
    [Table(name: "Step")]
    public class Step
    {
        [Key]
        public int ID { get; set; }

        [Column(TypeName ="varchar(500)")]
        [Required]
        public string StepName { get; set; }

        public ICollection<Item> items { get; set; }
    }
}
