﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.Model
{
    [Table(name: "Item")]
    public class Item
    {
        [Key]
        public int ID { get; set; }

        [Column(TypeName = "varchar(500)")]
        [Required]
        public string ItemName { get; set; }

        [Column(TypeName = "varchar(500)")]
        [Required]
        public string Description { get; set; }

        
        public int StepID { get; set; }

    }
}
