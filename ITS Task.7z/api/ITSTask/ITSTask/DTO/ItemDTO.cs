﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.DTO
{
    public class ItemDTO
    {
        public int ID { get; set; }
        public string ItemName { get; set; }
        public string Description { get; set; }
        public int StepID { get; set; }
    }
}
