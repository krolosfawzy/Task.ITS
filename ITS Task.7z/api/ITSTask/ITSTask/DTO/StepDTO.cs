﻿using ITSTask.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ITSTask.DTO
{
    public class StepDTO
    {
        public int ID { get; set; }
        public string StepName { get; set; }
        public ICollection<Item> items { get; set; }
    }
}
