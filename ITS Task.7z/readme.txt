hello there

//Angular project
before run need to
-write command =>npm i .


//API project 
before run need to
-delete Migrations folder.
-set your connection string.
-write command =>add-migration ITSTask_DB
	       =>Update-Database
	